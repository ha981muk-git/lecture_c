/* eigene Header-Datei fuer die Deklaration der Funktionen des Taschenrechners */

int add(int lhs, int rhs, char * prognam);

int subt(int lhs, int rhs, char * prognam);

int mult(int lhs, int rhs, char * prognam);

int divi(int lhs, int rhs, char * prognam);

int modulo(int lhs, int rhs, char * prognam);


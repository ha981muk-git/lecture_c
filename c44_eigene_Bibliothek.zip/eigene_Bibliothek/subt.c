int subt(int lhs, int rhs, char * prognam) {
	return lhs - rhs;
}

/* C-Demoprogramm fuer die Phasen des C-Compilers */

#define START 17

int main() {
	int a = START, b;
	
	b = 42 * a;

	return 0;
}
